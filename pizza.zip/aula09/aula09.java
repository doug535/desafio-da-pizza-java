package aula09;

/**
 * @author Douglas
 */

import java.util.Scanner;
 
public class aula09 {

	public static void main(String[] args) {
		
		//tamanhoP significa tamanho da Pizza
		//nomeP significa nome da Pizza

		double tamanhoP;
		double preco;
		String nomeP;
		
		Scanner ler = new Scanner(System.in);
		
		/**
		 * menu de pedido sobre tamanho pre�o e modelo da pizza para ver se vale ou n�o apena conprar
		 */
		
		System.out.println("--------pizza-------");
		
		System.out.println("");
		
		System.out.print("Tamanho da pizza: ");
		tamanhoP = ler.nextDouble();
		
		System.out.print("Pe�o da pizza: ");
		preco = ler.nextDouble();
		
		System.out.print("Nome da pizza: ");
		nomeP = ler.next();
		
		System.out.println("");
		
		System.out.println("--------------------");
		
		System.out.println("");
		
		System.out.println("sdfghjk");
		
		System.out.println("");
		
		System.out.println("--------------------");
		
	}

}
